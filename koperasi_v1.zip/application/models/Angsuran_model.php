<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Angsuran_model extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function get_data_kas(){
    $this->db->select('*');
    $this->db->from('nama_kas_tbl');
    $this->db->where('aktif', 'Y');
    $this->db->where('tmpl_bayar', 'Y');
    $this->db->order_by('id', 'ASC');
    $query = $this->db->get();
    if($query->num_rows()>0){
      $out = $query->result();
      return $out;
    } else {
      return FALSE;
    }
  }

  //panggil detail  angsuran
  function get_data_angsuran($pinjam_id) {
    $this->db->select('*');
    $this->db->from('tbl_pinjaman_d');
    $this->db->where('pinjam_id', $pinjam_id);
    $this->db->order_by('tgl_bayar', 'ASC');
    $query = $this->db->get();
    if($query->num_rows()>0){
      $out = $query->result();
      return $out;
    } else {
      return FALSE;
    }
  }

}
